public class Warrior extends Hero
{
    
   private int warriorHealth = 10;
   private int warriorAttackDamage = 5;
   private int warriorDefense = 6;
   private int warriorMagicResist = 4;
   private int warriorMagicAttack = 4;
   
   public Warrior()
   {
   
   }
   public void setWarriorHealth(int health)
   {
      warriorHealth = health;
   }
   public void setWarriorAD(int attackDamage)
   {
      warriorAttackDamage = attackDamage;
   }
   public void setWarriorDefense(int warriorDefense)
   {
      this.warriorDefense = warriorDefense;
   }
   public void setWMR(int magicResist)
   {
      warriorMagicResist = magicResist;
   }
   public void setWMA(int magicAttack)
   {
      warriorMagicAttack = magicAttack;
   }
   public int getWarriorHealth()
   {
      return warriorHealth;
   }
   public int getWarriorAD()
   {
      return warriorAttackDamage;
   }
   public int getWD()
   {
      return warriorDefense;
   }
   public int getWMR()
   {
      return warriorMagicResist;
   }
   public int getWMA()
   {
      return warriorMagicAttack;
   }
   
}