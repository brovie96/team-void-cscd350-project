public class Healer
{
   private int healerHealth = 10;
   private int healerAttackDamage = 5;
   private int healerDefense = 4;
   private int healerMagicResist = 6;
   private int healerMagicAttack = 7;
   
   public Healer()
   {
   
   }
   public void setHealerHealth(int health)
   {
      healerHealth = health;
   }
   public void setHealerAD(int attackDamage)
   {
      healerAttackDamage = attackDamage;
   }
   public void setHealerDefense(int healerDefense)
   {
      this.healerDefense = healerDefense;
   }
   public void setHMR(int magicResist)
   {
      healerMagicResist = magicResist;
   }
   public void setHMA(int magicAttack)
   {
      healerMagicAttack = magicAttack;
   }
   public int getHealerHealth()
   {
      return healerHealth;
   }
   public int getHealerAD()
   {
      return healerAttackDamage;
   }
   public int getHD()
   {
      return healerDefense;
   }
   public int getHMR()
   {
      return healerMagicResist;
   }
   public int getHMA()
   {
      return healerMagicAttack;
   }
}