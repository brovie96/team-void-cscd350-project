public class Hero
{

   
   
   public Hero()
   {
   
   }
   public void getAttackMove()
   {
      //this method will be to get the hero attackMove
   }
   public void getSpecialAttackMove()
   {
      //to get the special attack move
   }


}