public class Sorecor extends Hero
{
   private int sorecorHealth = 10;
   private int sorecorAttackDamage = 5;
   private int sorecorDefense = 4;
   private int sorecorMagicResist = 6;
   private int sorecorMagicAttack = 7;
   
   
   public Sorecor()
   {
   
   }
   public void setSorecorHealth(int health)
   {
      sorecorHealth = health;
   }
   public void setSorecorAD(int attackDamage)
   {
      sorecorAttackDamage = attackDamage;
   }
   public void setSorecorDefense(int sorecorDefense)
   {
      this.sorecorDefense = sorecorDefense;
   }
   public void setSMR(int magicResist)
   {
      sorecorMagicResist = magicResist;
   }
   public void setSMA(int magicAttack)
   {
      sorecorMagicAttack = magicAttack;
   }
   public int getSorecorHealth()
   {
      return sorecorHealth;
   }
   public int getSorecorAD()
   {
      return sorecorAttackDamage;
   }
   public int getSD()
   {
      return sorecorDefense;
   }
   public int getSMR()
   {
      return sorecorMagicResist;
   }
   public int getSMA()
   {
      return sorecorMagicAttack;
   }

}